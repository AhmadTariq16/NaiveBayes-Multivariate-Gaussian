clc;
clear all;
close all;

load ('parkinson-Training.mat');
TrainData=parkinson1;
traindata=TrainData(:,1:22); %training data
trainlabel=TrainData(:,23); %training data labels

load ('parkinson-Test.mat');
TestData=parkinson;
testdata=TestData(:,1:22); %test data
testlabel=TestData(:,23); %test data labels

classes= unique(trainlabel); %classes
numOfClasses= length(classes); %number of classes
ns=length(testlabel); %length of test set

% compute class probability 
for i=1:numOfClasses
    classProbability(i)=sum(double(trainlabel==classes(i)))/length(trainlabel);
end

 % parameters (mu, sigma) calcultion from training set
        for i=1:numOfClasses
            xi=traindata((trainlabel==classes(i)),:);
            mu(i,:)=mean(xi,1);
            sigma(i,:)=std(xi,1);
        end
       

% probability for test set
        for j=1:ns
            fu=normcdf(ones(numOfClasses,1)*traindata(j,:),mu,sigma);
            P(j,:)=classProbability.*prod(fu,2)';
        end

% get predicted output for test set
[pv0,id]=max(P,[],2);
for i=1:length(id)
    pv(i,1)=classes(id(i));
end

% compare predicted output with actual output from test data
confMat=confusionmat(testlabel,pv);
disp('confusion matrix:')
disp(confMat)
conf=sum(pv==testlabel)/length(pv);
disp(['accuracy = ',num2str(conf*100),'%'])

