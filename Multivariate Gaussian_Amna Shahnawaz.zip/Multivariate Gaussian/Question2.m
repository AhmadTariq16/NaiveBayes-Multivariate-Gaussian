clc;
clear all;

load 'banknote-traindata.mat';
trainData=traindata(:,1:4);
trainLabel=traindata(:,5);


load 'banknote-testdata.mat';
testData=testdata(:,1:4);
testLabel=testdata(:,5);

classes= unique(trainLabel); %classes
numOfClasses= length(classes); %number of classes
ns=length(testLabel); %length of test set

% compute class probability 
for i=1:numOfClasses
    classProbability(i)=sum(double(trainLabel==classes(i)))/length(trainLabel);
end

x0=trainData((trainLabel==classes(1)),:); %training data belonging to class 0
x1=trainData((trainLabel==classes(2)),:); %training data belonging to class 1
 
% parameters from training data

% mu 

for i=1:numOfClasses
            
            xi=trainData((trainLabel==classes(i)),:);
            mu(i,:)=mean(xi,1);
            
 end

%covariance
mean_subtract0 = bsxfun(@minus, x0, mu(1,:));
cov0 = (mean_subtract0.' * mean_subtract0) / size(x0,1);

mean_subtract1 = bsxfun(@minus, x1, mu(2,:));        
cov1 = (mean_subtract1.' * mean_subtract1) / size(x1,1);
cov={cov0, cov1};

p(:,1)=mvnpdf(testData, mu(1,:),cov0);
p(:,2)=mvnpdf(testData, mu(2,:),cov1);

for k=1:1:2
    
    Pr(:,k)=classProbability(1).*p(:,k);
end

%Pr=Pr';

[pv0,id]=max(Pr,[],2);
for i=1:length(id)
    pv(i,1)=classes(id(i));
end

% compare predicted output with actual output from test data
confMat=confusionmat(testLabel,pv);
disp('confusion matrix:')
disp(confMat)
conf=sum(pv==testLabel)/length(pv);
disp(['accuracy = ',num2str(conf*100),'%'])
count=0;
% First column of result shows actual labels and second column shows
% predicted labels
for i=1:length(pv)
    result(i,1)=testLabel(i);
    result(i,2)=pv(i);
end
result

TP=confMat(1,1);
FN=confMat(2,1);
FP=confMat(1,2);
TN=confMat(2,2);

Sensitivity = TP/(TP+FN)
Specificity = TN/(TN+FP)
fileId =fopen('Output.txt', 'wt');
fprintf(fileId,'%g\n',pv);
fclose(fileId);

    